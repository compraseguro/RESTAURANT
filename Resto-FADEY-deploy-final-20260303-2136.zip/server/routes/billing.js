const express = require('express');
const { v4: uuidv4 } = require('uuid');
const { queryAll, queryOne, runSql } = require('../database');
const { authenticateToken, requireRole } = require('../middleware/auth');

const router = express.Router();

const DOCS = {
  boleta: { sunatCode: '03', nubefactCode: '2', fallbackSeries: 'B001' },
  factura: { sunatCode: '01', nubefactCode: '1', fallbackSeries: 'F001' },
};

function toNumber(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

function round2(value) {
  return Math.round(toNumber(value) * 100) / 100;
}

function normalizeSeries(value, fallback) {
  const clean = String(value || '').trim().toUpperCase();
  return clean || fallback;
}

function formatIssueDate(date = new Date()) {
  const dd = String(date.getDate()).padStart(2, '0');
  const mm = String(date.getMonth() + 1).padStart(2, '0');
  const yyyy = date.getFullYear();
  return `${dd}-${mm}-${yyyy}`;
}

function normalizeCustomerForDoc(docType, customer = {}) {
  const rawDocType = String(customer.doc_type || '').trim();
  const rawDocNumber = String(customer.doc_number || '').trim();
  const rawName = String(customer.name || '').trim();
  const rawAddress = String(customer.address || '').trim();

  const customerDocType = rawDocType || (docType === 'factura' ? '6' : '1');
  const customerDocNumber = rawDocNumber;
  const customerName = rawName || 'CLIENTE VARIOS';
  const customerAddress = rawAddress || 'LIMA';

  if (docType === 'factura') {
    if (customerDocType !== '6') {
      throw new Error('Para factura el tipo de documento del cliente debe ser RUC');
    }
    if (!/^\d{11}$/.test(customerDocNumber)) {
      throw new Error('Para factura debes ingresar un RUC válido de 11 dígitos');
    }
    if (!rawName) {
      throw new Error('Para factura debes ingresar razón social del cliente');
    }
  }

  if (customerDocType === '1' && customerDocNumber && !/^\d{8}$/.test(customerDocNumber)) {
    throw new Error('DNI inválido, debe tener 8 dígitos');
  }
  if (customerDocType === '6' && customerDocNumber && !/^\d{11}$/.test(customerDocNumber)) {
    throw new Error('RUC inválido, debe tener 11 dígitos');
  }

  return { customerDocType, customerDocNumber, customerName, customerAddress };
}

function getNextCorrelative(docType, series) {
  const row = queryOne(
    'SELECT COALESCE(MAX(correlative), 0) as max_number FROM electronic_documents WHERE doc_type = ? AND series = ?',
    [docType, series]
  );
  return Number(row?.max_number || 0) + 1;
}

function canSendToProvider(restaurant) {
  return Number(restaurant.billing_enabled || 0) === 1
    && String(restaurant.billing_provider || '').toLowerCase() === 'nubefact'
    && Boolean(String(restaurant.billing_api_url || '').trim())
    && Boolean(String(restaurant.billing_api_token || '').trim());
}

async function checkProviderReachability(restaurant) {
  if (!String(restaurant?.billing_api_url || '').trim()) return false;
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 2500);
    const response = await fetch(String(restaurant.billing_api_url).trim(), {
      method: 'GET',
      signal: controller.signal,
    });
    clearTimeout(timeout);
    return Boolean(response);
  } catch (_) {
    return false;
  }
}

function isOfflineModeEnabled(restaurant) {
  return Number(restaurant?.billing_offline_mode ?? 1) === 1;
}

function parseProviderPayload(rawPayload) {
  try {
    const payload = JSON.parse(rawPayload || '{}');
    return payload && typeof payload === 'object' ? payload : {};
  } catch (_) {
    return {};
  }
}

function applyProviderResultToDocument(docId, result) {
  runSql(
    `UPDATE electronic_documents
     SET provider_status = ?, provider_message = ?, hash_code = ?, sunat_description = ?,
         xml_url = ?, cdr_url = ?, pdf_url = ?, provider_response = ?, updated_at = datetime('now')
     WHERE id = ?`,
    [
      result.providerStatus,
      String(result.providerMessage || ''),
      String(result.hashCode || ''),
      String(result.sunatDescription || ''),
      String(result.xmlUrl || ''),
      String(result.cdrUrl || ''),
      String(result.pdfUrl || ''),
      JSON.stringify(result.providerResponse || {}),
      docId,
    ]
  );
}

async function sendToProvider(restaurant, providerPayload) {
  const initial = {
    providerStatus: 'pending',
    providerMessage: 'Comprobante generado localmente (pendiente de envío)',
    hashCode: '',
    sunatDescription: '',
    xmlUrl: '',
    cdrUrl: '',
    pdfUrl: '',
    providerResponse: {},
  };

  if (!canSendToProvider(restaurant)) {
    return initial;
  }

  try {
    const response = await fetch(String(restaurant.billing_api_url).trim(), {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Token token=${String(restaurant.billing_api_token).trim()}`,
      },
      body: JSON.stringify(providerPayload),
    });

    const rawText = await response.text();
    let parsed = {};
    try {
      parsed = rawText ? JSON.parse(rawText) : {};
    } catch (_) {
      parsed = { raw: rawText };
    }

    if (!response.ok) {
      return {
        ...initial,
        providerStatus: 'error',
        providerMessage: parsed?.errors || parsed?.error || `Error HTTP ${response.status}`,
        providerResponse: parsed,
      };
    }

    const hashCode = parsed?.cadena_para_codigo_qr || parsed?.hash || '';
    const sunatDescription = parsed?.sunat_description || parsed?.mensaje || '';
    const xmlUrl = parsed?.enlace_del_xml || '';
    const cdrUrl = parsed?.enlace_del_cdr || '';
    const pdfUrl = parsed?.enlace_del_pdf || parsed?.pdf || '';
    const providerMessage = parsed?.mensaje || parsed?.sunat_description || 'Comprobante enviado al proveedor';
    const accepted = String(parsed?.sunat_description || '').toUpperCase().includes('ACEPTADA')
      || String(parsed?.aceptada || '').toLowerCase() === 'true'
      || String(parsed?.aceptada || '') === '1';

    return {
      providerStatus: accepted ? 'accepted' : 'sent',
      providerMessage,
      hashCode,
      sunatDescription,
      xmlUrl,
      cdrUrl,
      pdfUrl,
      providerResponse: parsed,
    };
  } catch (providerErr) {
    if (isOfflineModeEnabled(restaurant)) {
      return {
        ...initial,
        providerStatus: 'pending',
        providerMessage: 'Sin conexión: comprobante guardado en modo offline para sincronizar',
        providerResponse: { offline: true, error: providerErr.message || 'Sin conexión' },
      };
    }
    return {
      ...initial,
      providerStatus: 'error',
      providerMessage: providerErr.message || 'No se pudo conectar con el proveedor',
      providerResponse: { error: providerErr.message || 'No se pudo conectar con el proveedor' },
    };
  }
}

function buildNubefactPayload({ restaurant, order, items, customer, docType, series, correlative }) {
  const taxRate = toNumber(restaurant.tax_rate, 18);
  const subtotal = round2(order.subtotal);
  const tax = round2(order.tax);
  const total = round2(order.total);

  const mappedItems = items.map((item) => {
    const quantity = toNumber(item.quantity, 0);
    const valorUnitario = round2(item.unit_price);
    const precioUnitario = round2(valorUnitario * (1 + taxRate / 100));
    const lineSubtotal = round2(item.subtotal);
    const lineTax = round2(lineSubtotal * (taxRate / 100));
    const lineTotal = round2(lineSubtotal + lineTax);

    return {
      unidad_de_medida: 'NIU',
      codigo: item.product_id || '',
      descripcion: item.product_name || 'Producto',
      cantidad: quantity,
      valor_unitario: valorUnitario,
      precio_unitario: precioUnitario,
      descuento: '',
      subtotal: lineSubtotal,
      tipo_de_igv: 1,
      igv: lineTax,
      total: lineTotal,
      anticipo_regularizacion: false,
    };
  });

  return {
    operacion: 'generar_comprobante',
    tipo_de_comprobante: DOCS[docType].nubefactCode,
    serie,
    numero: correlative,
    sunat_transaction: 1,
    cliente_tipo_de_documento: customer.customerDocType || '0',
    cliente_numero_de_documento: customer.customerDocNumber || '',
    cliente_denominacion: customer.customerName,
    cliente_direccion: customer.customerAddress || 'LIMA',
    fecha_de_emision: formatIssueDate(),
    moneda: (restaurant.currency || 'PEN') === 'USD' ? '2' : '1',
    porcentaje_de_igv: taxRate,
    total_gravada: subtotal,
    total_igv: tax,
    total: total,
    enviar_automaticamente_a_la_sunat: true,
    enviar_automaticamente_al_cliente: false,
    codigo_unico: String(order.id || ''),
    condiciones_de_pago: '',
    medio_de_pago: order.payment_method || 'efectivo',
    placa_vehiculo: '',
    orden_compra_servicio: '',
    tabla_personalizada_codigo: '',
    formato_de_pdf: '',
    observaciones: order.notes || '',
    items: mappedItems,
  };
}

router.get('/config', authenticateToken, requireRole('admin'), (req, res) => {
  const restaurant = queryOne('SELECT * FROM restaurants LIMIT 1');
  if (!restaurant) return res.status(404).json({ error: 'Restaurante no encontrado' });
  res.json({
    company_ruc: restaurant.company_ruc || '',
    legal_name: restaurant.legal_name || '',
    billing_enabled: Number(restaurant.billing_enabled || 0),
    billing_provider: restaurant.billing_provider || 'nubefact',
    billing_api_url: restaurant.billing_api_url || '',
    billing_api_token: '',
    has_billing_api_token: Boolean((restaurant.billing_api_token || '').trim()),
    billing_series_boleta: restaurant.billing_series_boleta || 'B001',
    billing_series_factura: restaurant.billing_series_factura || 'F001',
    billing_offline_mode: Number(restaurant.billing_offline_mode ?? 1),
    billing_auto_retry_enabled: Number(restaurant.billing_auto_retry_enabled ?? 1),
    billing_auto_retry_interval_sec: Number(restaurant.billing_auto_retry_interval_sec || 120),
  });
});

router.put('/config', authenticateToken, requireRole('admin'), (req, res) => {
  try {
    const current = queryOne('SELECT * FROM restaurants LIMIT 1');
    if (!current) return res.status(404).json({ error: 'Restaurante no encontrado' });

    const {
      company_ruc,
      legal_name,
      billing_enabled,
      billing_provider,
      billing_api_url,
      billing_api_token,
      billing_series_boleta,
      billing_series_factura,
      billing_offline_mode,
      billing_auto_retry_enabled,
      billing_auto_retry_interval_sec,
    } = req.body || {};

    const nextToken = String(billing_api_token || '').trim()
      ? String(billing_api_token || '').trim()
      : (current.billing_api_token || '');

    runSql(
      `UPDATE restaurants SET
        company_ruc = ?,
        legal_name = ?,
        billing_enabled = ?,
        billing_provider = ?,
        billing_api_url = ?,
        billing_api_token = ?,
        billing_series_boleta = ?,
        billing_series_factura = ?,
        billing_offline_mode = ?,
        billing_auto_retry_enabled = ?,
        billing_auto_retry_interval_sec = ?,
        updated_at = datetime('now')
      WHERE id = ?`,
      [
        String(company_ruc || '').trim(),
        String(legal_name || '').trim(),
        Number(billing_enabled ? 1 : 0),
        String(billing_provider || 'nubefact').trim() || 'nubefact',
        String(billing_api_url || '').trim(),
        nextToken,
        normalizeSeries(billing_series_boleta, 'B001'),
        normalizeSeries(billing_series_factura, 'F001'),
        Number(billing_offline_mode ? 1 : 0),
        Number(billing_auto_retry_enabled ? 1 : 0),
        Math.max(30, Math.min(3600, Number(billing_auto_retry_interval_sec || 120))),
        current.id,
      ]
    );

    const updated = queryOne('SELECT * FROM restaurants WHERE id = ?', [current.id]);
    res.json({
      company_ruc: updated.company_ruc || '',
      legal_name: updated.legal_name || '',
      billing_enabled: Number(updated.billing_enabled || 0),
      billing_provider: updated.billing_provider || 'nubefact',
      billing_api_url: updated.billing_api_url || '',
      billing_api_token: '',
      has_billing_api_token: Boolean((updated.billing_api_token || '').trim()),
      billing_series_boleta: updated.billing_series_boleta || 'B001',
      billing_series_factura: updated.billing_series_factura || 'F001',
      billing_offline_mode: Number(updated.billing_offline_mode ?? 1),
      billing_auto_retry_enabled: Number(updated.billing_auto_retry_enabled ?? 1),
      billing_auto_retry_interval_sec: Number(updated.billing_auto_retry_interval_sec || 120),
    });
  } catch (err) {
    res.status(500).json({ error: err.message || 'No se pudo guardar la configuración de facturación' });
  }
});

router.get('/documents', authenticateToken, requireRole('admin', 'cajero'), (req, res) => {
  try {
    const limit = Math.max(1, Math.min(200, Number(req.query.limit || 50)));
    const status = String(req.query.status || '').trim();
    const docType = String(req.query.doc_type || '').trim();
    const search = String(req.query.search || '').trim();

    let sql = `SELECT d.*, o.table_number
      FROM electronic_documents d
      LEFT JOIN orders o ON o.id = d.order_id
      WHERE 1=1`;
    const params = [];

    if (status && status !== 'all') {
      sql += ' AND d.provider_status = ?';
      params.push(status);
    }
    if (docType && docType !== 'all') {
      sql += ' AND d.doc_type = ?';
      params.push(docType);
    }
    if (search) {
      sql += ` AND (
        d.full_number LIKE ?
        OR d.customer_name LIKE ?
        OR d.customer_doc_number LIKE ?
      )`;
      params.push(`%${search}%`, `%${search}%`, `%${search}%`);
    }

    sql += ' ORDER BY d.created_at DESC LIMIT ?';
    params.push(limit);
    const rows = queryAll(sql, params);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message || 'No se pudo listar comprobantes' });
  }
});

router.get('/provider-status', authenticateToken, requireRole('admin', 'cajero', 'mozo'), async (req, res) => {
  try {
    const restaurant = queryOne('SELECT * FROM restaurants LIMIT 1');
    if (!restaurant) return res.status(404).json({ error: 'Restaurante no encontrado' });
    const pendingCount = queryOne(
      "SELECT COUNT(*) as c FROM electronic_documents WHERE provider_status IN ('pending', 'error')"
    )?.c || 0;
    const reachable = await checkProviderReachability(restaurant);

    res.json({
      billing_enabled: Number(restaurant.billing_enabled || 0),
      offline_mode: Number(restaurant.billing_offline_mode ?? 1),
      auto_retry_enabled: Number(restaurant.billing_auto_retry_enabled ?? 1),
      auto_retry_interval_sec: Number(restaurant.billing_auto_retry_interval_sec || 120),
      provider_reachable: reachable,
      pending_documents: Number(pendingCount || 0),
      checked_at: new Date().toISOString(),
    });
  } catch (err) {
    res.status(500).json({ error: err.message || 'No se pudo consultar estado del proveedor' });
  }
});

async function issueDocumentForOrder({ orderId, docType, customer = {}, replaceExisting = false }) {
  if (!orderId) throw new Error('Debes enviar order_id');
  if (!DOCS[docType] && docType !== 'nota_venta') throw new Error('Tipo de comprobante inválido');

  const existingDoc = queryOne('SELECT * FROM electronic_documents WHERE order_id = ?', [orderId]);
  if (existingDoc && !replaceExisting) return existingDoc;

  const order = queryOne('SELECT * FROM orders WHERE id = ?', [orderId]);
  if (!order) throw new Error('Pedido no encontrado');
  if (docType === 'nota_venta') {
    const noteNumber = order.sale_document_number || `001-${String(order.order_number || 0).padStart(8, '0')}`;
    runSql(
      "UPDATE orders SET sale_document_type = 'nota_venta', sale_document_number = ?, updated_at = datetime('now') WHERE id = ?",
      [noteNumber, orderId]
    );
    runSql('DELETE FROM electronic_documents WHERE order_id = ?', [orderId]);
    return {
      id: `nota-${orderId}`,
      order_id: orderId,
      order_number: order.order_number || null,
      doc_type: 'nota_venta',
      full_number: noteNumber,
      provider_status: 'local',
      provider_message: 'Nota de venta local',
      payment_method: order.payment_method || 'efectivo',
    };
  }
  const items = queryAll('SELECT * FROM order_items WHERE order_id = ?', [orderId]);
  if (items.length === 0) throw new Error('El pedido no tiene items');

  const restaurant = queryOne('SELECT * FROM restaurants LIMIT 1');
  if (!restaurant) throw new Error('No hay restaurante configurado');

  const sourceCustomer = {
    doc_type: customer?.doc_type || existingDoc?.customer_doc_type || '',
    doc_number: customer?.doc_number || existingDoc?.customer_doc_number || '',
    name: customer?.name || existingDoc?.customer_name || order.customer_name || 'CLIENTE VARIOS',
    address: customer?.address || existingDoc?.customer_address || 'LIMA',
  };
  const normalizedCustomer = normalizeCustomerForDoc(docType, sourceCustomer);
  const series = normalizeSeries(
    docType === 'factura' ? restaurant.billing_series_factura : restaurant.billing_series_boleta,
    DOCS[docType].fallbackSeries
  );
  const correlative = getNextCorrelative(docType, series);
  const fullNumber = `${series}-${String(correlative).padStart(8, '0')}`;

  const providerPayload = buildNubefactPayload({
    restaurant,
    order,
    items,
    customer: normalizedCustomer,
    docType,
    series,
    correlative,
  });

  const {
    providerStatus,
    providerMessage,
    hashCode,
    sunatDescription,
    xmlUrl,
    cdrUrl,
    pdfUrl,
    providerResponse,
  } = await sendToProvider(restaurant, providerPayload);

  if (replaceExisting && existingDoc) {
    runSql('DELETE FROM electronic_documents WHERE order_id = ?', [orderId]);
  }

  const docId = uuidv4();
  runSql(
    `INSERT INTO electronic_documents (
      id, order_id, order_number, doc_type, series, correlative, full_number,
      customer_doc_type, customer_doc_number, customer_name, customer_address,
      subtotal, tax, total, currency, payment_method,
      provider, provider_status, provider_message, hash_code, sunat_description,
      xml_url, cdr_url, pdf_url, provider_payload, provider_response,
      created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))`,
    [
      docId,
      order.id,
      order.order_number || null,
      docType,
      series,
      correlative,
      fullNumber,
      normalizedCustomer.customerDocType,
      normalizedCustomer.customerDocNumber,
      normalizedCustomer.customerName,
      normalizedCustomer.customerAddress,
      round2(order.subtotal),
      round2(order.tax),
      round2(order.total),
      restaurant.currency || 'PEN',
      order.payment_method || '',
      restaurant.billing_provider || 'nubefact',
      providerStatus,
      String(providerMessage || ''),
      String(hashCode || ''),
      String(sunatDescription || ''),
      String(xmlUrl || ''),
      String(cdrUrl || ''),
      String(pdfUrl || ''),
      JSON.stringify(providerPayload),
      JSON.stringify(providerResponse || {}),
    ]
  );

  runSql(
    `UPDATE orders
     SET sale_document_type = ?,
         sale_document_number = ?,
         customer_name = ?,
         updated_at = datetime('now')
     WHERE id = ?`,
    [docType, fullNumber, normalizedCustomer.customerName, orderId]
  );

  return queryOne('SELECT * FROM electronic_documents WHERE id = ?', [docId]);
}

router.post('/issue', authenticateToken, requireRole('admin', 'cajero', 'mozo'), async (req, res) => {
  try {
    const { order_id: orderId, doc_type: docTypeRaw, customer } = req.body || {};
    const docType = String(docTypeRaw || '').trim().toLowerCase();
    const created = await issueDocumentForOrder({ orderId, docType, customer, replaceExisting: false });
    res.json(created);
  } catch (err) {
    res.status(500).json({ error: err.message || 'No se pudo emitir comprobante electrónico' });
  }
});

router.put('/order/:orderId/document', authenticateToken, requireRole('admin', 'cajero', 'mozo'), async (req, res) => {
  try {
    const { orderId } = req.params;
    const { doc_type: docTypeRaw, customer } = req.body || {};
    const docType = String(docTypeRaw || '').trim().toLowerCase();
    const created = await issueDocumentForOrder({ orderId, docType, customer, replaceExisting: true });
    res.json(created);
  } catch (err) {
    res.status(500).json({ error: err.message || 'No se pudo cambiar el comprobante' });
  }
});

router.post('/:id/retry', authenticateToken, requireRole('admin', 'cajero'), async (req, res) => {
  try {
    const doc = queryOne('SELECT * FROM electronic_documents WHERE id = ?', [req.params.id]);
    if (!doc) return res.status(404).json({ error: 'Comprobante no encontrado' });
    if (!['error', 'pending', 'sent'].includes(String(doc.provider_status || '').toLowerCase())) {
      return res.status(400).json({ error: 'El comprobante no requiere reintento' });
    }

    const restaurant = queryOne('SELECT * FROM restaurants LIMIT 1');
    if (!restaurant) return res.status(400).json({ error: 'No hay restaurante configurado' });

    const payload = parseProviderPayload(doc.provider_payload);
    if (!payload || Object.keys(payload).length === 0) {
      return res.status(400).json({ error: 'No hay payload para reintentar este comprobante' });
    }

    const result = await sendToProvider(restaurant, payload);
    applyProviderResultToDocument(doc.id, result);

    const updated = queryOne('SELECT * FROM electronic_documents WHERE id = ?', [doc.id]);
    res.json(updated);
  } catch (err) {
    res.status(500).json({ error: err.message || 'No se pudo reintentar el comprobante' });
  }
});

async function retryFailedDocumentsBatch({ limit = 20 } = {}) {
  const restaurant = queryOne('SELECT * FROM restaurants LIMIT 1');
  if (!restaurant) return { processed: 0, success: 0, failed: 0, skipped: true };
  if (!canSendToProvider(restaurant)) return { processed: 0, success: 0, failed: 0, skipped: true };

  const rows = queryAll(
    `SELECT * FROM electronic_documents
     WHERE provider_status IN ('error', 'pending')
     ORDER BY updated_at ASC
     LIMIT ?`,
    [Math.max(1, Math.min(50, Number(limit || 20)))]
  );

  let processed = 0;
  let success = 0;
  for (const row of rows) {
    const payload = parseProviderPayload(row.provider_payload);
    if (!payload || Object.keys(payload).length === 0) continue;
    const result = await sendToProvider(restaurant, payload);
    applyProviderResultToDocument(row.id, result);
    processed += 1;
    if (result.providerStatus === 'accepted' || result.providerStatus === 'sent') success += 1;
  }
  return { processed, success, failed: Math.max(0, processed - success), skipped: false };
}

router.post('/retry-failed', authenticateToken, requireRole('admin', 'cajero'), async (req, res) => {
  try {
    const result = await retryFailedDocumentsBatch({ limit: req.body?.limit || 20 });
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message || 'No se pudo ejecutar reintento masivo' });
  }
});

let autoRetryTimer = null;
let autoRetryRunning = false;
let autoRetryLastRunMs = 0;

function startBillingAutoRetryJob() {
  if (autoRetryTimer) return;
  autoRetryTimer = setInterval(async () => {
    if (autoRetryRunning) return;
    try {
      const restaurant = queryOne('SELECT * FROM restaurants LIMIT 1');
      if (!restaurant) return;
      if (Number(restaurant.billing_auto_retry_enabled ?? 1) !== 1) return;
      const intervalSec = Math.max(30, Math.min(3600, Number(restaurant.billing_auto_retry_interval_sec || 120)));
      const now = Date.now();
      if (now - autoRetryLastRunMs < intervalSec * 1000) return;
      autoRetryRunning = true;
      autoRetryLastRunMs = now;
      await retryFailedDocumentsBatch({ limit: 20 });
    } catch (_) {
      // Silent by design: this runs in background.
    } finally {
      autoRetryRunning = false;
    }
  }, 10000);
}

module.exports = router;
module.exports.startBillingAutoRetryJob = startBillingAutoRetryJob;
